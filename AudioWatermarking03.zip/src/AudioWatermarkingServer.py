from flask import Flask, request, render_template, redirect, url_for, session
import os
import pypyodbc
import zipfile
import numpy as np
import cv2
from os.path import isfile, join

import timeit
import numpy as np
from scipy.io import wavfile
import pickle
import random
import math
import sys
import os
os.environ['CUDA_VISIBLE_DEVICES'] = '0'

import tensorflow as tf

from RoleModel import RoleModel
from UserModel import UserModel
from Constants import connString


app = Flask(__name__)
app.secret_key = "MySecret"
ctx = app.app_context()
ctx.push()

with ctx:
    pass

userName = ""
roleObject = None
message = ""
msgType = ""

def initialize():
    global message, msgType
    message = ""
    msgType=""

def processRole(optionID):
    
    if optionID == 10 :
        if roleObject.canRole == False :
            return False
    if optionID == 20 :
        if roleObject.canUser == False :
            return False
    if optionID == 30 :
        if roleObject.CL111 == False :
            return False
    if optionID == 40 :
        if roleObject.CL222 == False :
            return False
    if optionID == 50 :
        if roleObject.CL333 == False :
            return False
    return True

@app.route('/')
def index():
    global userID, userName
    return render_template('Login.html')  # when the home page is called Index.hrml will be triggered.

@app.route('/processLogin', methods=['POST'])
def processLogin():
    global userID, userName, roleObject
    userName= request.form['userName']
    password= request.form['password']
    conn1 = pypyodbc.connect(connString, autocommit=True)
    cur1 = conn1.cursor()
    sqlcmd1 = "SELECT * FROM UserTable WHERE userName = '"+userName+"' AND password = '"+password+"' AND isActive = 1"; 
    
    cur1.execute(sqlcmd1)
    row = cur1.fetchone()
    
    cur1.commit()
    if not row:
        return render_template('Login.html', processResult="Invalid Credentials")
    userID = row[0]
    userName = row[3]
    
    cur2 = conn1.cursor()
    sqlcmd2 = "SELECT * FROM Role WHERE RoleID = '"+str(row[6])+"'"; 
    cur2.execute(sqlcmd2)
    row2 = cur2.fetchone()
   
    if not row2:
        return render_template('Login.html', processResult="Invalid Role")
    
    roleObject = RoleModel(row2[0], row2[1],row2[2],row2[3],row2[4],row2[5])

    return render_template('Dashboard.html')

@app.route("/ChangePassword")
def changePassword():
    global userID, userName
    return render_template('ChangePassword.html')

@app.route("/ProcessChangePassword", methods=['POST'])
def processChangePassword():
    global userID, userName
    oldPassword= request.form['oldPassword']
    newPassword= request.form['newPassword']
    confirmPassword= request.form['confirmPassword']
    conn1 = pypyodbc.connect(connString, autocommit=True)
    cur1 = conn1.cursor()
    sqlcmd1 = "SELECT * FROM UserTable WHERE userName = '"+userName+"' AND password = '"+oldPassword+"'"; 
    cur1.execute(sqlcmd1)
    row = cur1.fetchone()
    cur1.commit()
    if not row:
        return render_template('ChangePassword.html', msg="Invalid Old Password")
    
    if newPassword.strip() != confirmPassword.strip() :
       return render_template('ChangePassword.html', msg="New Password and Confirm Password are NOT same")
    
    conn2 = pypyodbc.connect(connString, autocommit=True)
    cur2 = conn2.cursor()
    sqlcmd2 = "UPDATE UserTable SET password = '"+newPassword+"' WHERE userName = '"+userName+"'"; 
    cur1.execute(sqlcmd2)
    cur2.commit()
    return render_template('ChangePassword.html', msg="Password Changed Successfully")


@app.route("/Dashboard")
def Dashboard():
    global userID, userName
    return render_template('Dashboard.html')


@app.route("/Information")
def Information():
    global message, msgType
    return render_template('Information.html', msgType=msgType, message = message)




@app.route("/UserListing")

def UserListing():
    global userID, userName
    
    global message, msgType, roleObject
    if roleObject == None:
        message = "Application Error Occurred"
        msgType="Error"
        return redirect(url_for('Information'))
    canRole = processRole(10)

    if canRole == False:
        message = "You Don't Have Permission to Access User"
        msgType="Error"
        return redirect(url_for('Information'))
    
    conn2 = pypyodbc.connect(connString, autocommit=True)
    cursor = conn2.cursor()
    sqlcmd1 = "SELECT * FROM UserTable ORDER BY userName"
    cursor.execute(sqlcmd1)
    records = []
    
    while True:
        dbrow = cursor.fetchone()
        if not dbrow:
            break
        
        conn3 = pypyodbc.connect(connString, autocommit=True)
        cursor3 = conn3.cursor()
        temp = str(dbrow[6])
        sqlcmd3 = "SELECT * FROM Role WHERE RoleID = '"+temp+"'"
        cursor3.execute(sqlcmd3)
        rolerow = cursor3.fetchone()
        roleModel = RoleModel(0)
        if rolerow:
           roleModel = RoleModel(rolerow[0],rolerow[1])
        else:
           print("Role Row is Not Available")
        
        row = UserModel(dbrow[0], dbrow[1], dbrow[2], dbrow[3], dbrow[4], dbrow[5], dbrow[6], roleModel=roleModel)
        records.append(row)
    return render_template('UserListing.html', records=records)


@app.route("/UserOperation")
def UserOperation():
    
    global userID, userName
    
    global message, msgType, roleObject
    if roleObject == None:
        message = "Application Error Occurred"
        msgType="Error"
        return redirect(url_for('Information'))
    canRole = processRole(10)

    if canRole == False:
        message = "You Don't Have Permission to Access User"
        msgType="Error"
        return redirect(url_for('Information'))
    
    operation = request.args.get('operation')
    unqid = ""
    
    
    
    rolesDDList = []
    
    conn4 = pypyodbc.connect(connString, autocommit=True)
    cursor4 = conn4.cursor()
    sqlcmd4 = "SELECT * FROM Role"
    cursor4.execute(sqlcmd4)
    print("sqlcmd4???????????????????????????????????????????????????????/", sqlcmd4)
    while True:
        roleDDrow = cursor4.fetchone()
        if not roleDDrow:
            break
        print("roleDDrow[1]>>>>>>>>>>>>>>>>>>>>>>>>>", roleDDrow[1])
        roleDDObj = RoleModel(roleDDrow[0], roleDDrow[1])
        rolesDDList.append(roleDDObj)
        
        
    row = UserModel(0)

    if operation != "Create" :
        unqid = request.args.get('unqid').strip()
        conn2 = pypyodbc.connect(connString, autocommit=True)
        cursor = conn2.cursor()
        sqlcmd1 = "SELECT * FROM UserTable WHERE UserID = '"+unqid+"'"
        cursor.execute(sqlcmd1)
        dbrow = cursor.fetchone()
        if dbrow:
            
            conn3 = pypyodbc.connect(connString, autocommit=True)
            cursor3 = conn3.cursor()
            temp = str(dbrow[6])
            sqlcmd3 = "SELECT * FROM Role WHERE RoleID = '"+temp+"'"
            cursor3.execute(sqlcmd3)
            rolerow = cursor3.fetchone()
            roleModel = RoleModel(0)
            if rolerow:
               roleModel = RoleModel(rolerow[0],rolerow[1])
            else:
               print("Role Row is Not Available")
            row = UserModel(dbrow[0], dbrow[1], dbrow[2], dbrow[3], dbrow[4], dbrow[5], dbrow[6], roleModel=roleModel)
        
    return render_template('UserOperation.html', row = row, operation=operation, rolesDDList=rolesDDList )




@app.route("/ProcessUserOperation",methods = ['POST'])
def processUserOperation():
    global userName, userID
    operation = request.form['operation']
    unqid = request.form['unqid'].strip()
    userName= request.form['userName']
    emailid= request.form['emailid']
    password=request.form['password']
    contactNo= request.form['contactNo']
    isActive = 0
    if request.form.get("isActive") != None :
        isActive = 1
    roleID= request.form['roleID']
    
    
    conn1 = pypyodbc.connect(connString, autocommit=True)
    cur1 = conn1.cursor()
    
    
    if operation == "Create" :
        sqlcmd = "INSERT INTO UserTable( userName,emailid, password,contactNo, isActive, roleID) VALUES('"+userName+"','"+emailid+"', '"+password+"' , '"+contactNo+"', '"+str(isActive)+"', '"+str(roleID)+"')"
    if operation == "Edit" :
        sqlcmd = "UPDATE UserTable SET userName = '"+userName+"', emailid = '"+emailid+"', password = '"+password+"',contactNo='"+contactNo+"',  isActive = '"+str(isActive)+"', roleID = '"+str(roleID)+"' WHERE UserID = '"+unqid+"'"  
    if operation == "Delete" :

        sqlcmd = "DELETE FROM UserTable WHERE UserID = '"+unqid+"'" 

    if sqlcmd == "" :
        return redirect(url_for('Information')) 
    cur1.execute(sqlcmd)
    cur1.commit()
    conn1.close()
    return redirect(url_for("UserListing"))







'''
    Role Operation Start
'''

@app.route("/RoleListing")
def RoleListing():
    
    global message, msgType
    print("roleObject>>>>>>>>>>>>>>>>>>>>>>>>>>>>>", roleObject)
    if roleObject == None:
        message = "Application Error Occurred"
        msgType="Error"
        return redirect(url_for('Information'))
    canRole = processRole(20)

    if canRole == False:
        message = "You Don't Have Permission to Access Role"
        msgType="Error"
        return redirect(url_for('Information'))
    
    searchData = request.args.get('searchData')
    print(searchData)
    if searchData == None:
        searchData = "";
    conn2 = pypyodbc.connect(connString, autocommit=True)
    cursor = conn2.cursor()
    sqlcmd1 = "SELECT * FROM Role WHERE roleName LIKE '"+searchData+"%'"
    print(sqlcmd1)
    cursor.execute(sqlcmd1)
    records = []
    
    while True:
        dbrow = cursor.fetchone()
        if not dbrow:
            break
        
        row = RoleModel(dbrow[0],dbrow[1],dbrow[2],dbrow[3],dbrow[4],dbrow[5],dbrow[6])
        
        records.append(row)
    
    return render_template('RoleListing.html', records=records, searchData=searchData)

@app.route("/RoleOperation")
def RoleOperation():
    
    global message, msgType
    if roleObject == None:
        message = "Application Error Occurred"
        msgType="Error"
        return redirect(url_for('/'))
    canRole = processRole(120)

    if canRole == False:
        message = "You Don't Have Permission to Access Role"
        msgType="Error"
        return redirect(url_for('Information'))
    
    operation = request.args.get('operation')
    unqid = ""
    row = RoleModel(0, "",0,0,0,0)
    if operation != "Create" :
        unqid = request.args.get('unqid').strip()
        
        
        conn2 = pypyodbc.connect(connString, autocommit=True)
        cursor = conn2.cursor()
        sqlcmd1 = "SELECT * FROM Role WHERE RoleID = '"+unqid+"'"
        cursor.execute(sqlcmd1)
        while True:
            dbrow = cursor.fetchone()
            if not dbrow:
                break
            row = RoleModel(dbrow[0],dbrow[1],dbrow[2],dbrow[3],dbrow[4],dbrow[5],dbrow[6])
        
    return render_template('RoleOperation.html', row = row, operation=operation )


@app.route("/ProcessRoleOperation", methods=['POST'])
def ProcessRoleOperation():
    global message, msgType
    if roleObject == None:
        message = "Application Error Occurred"
        msgType="Error"
        return redirect(url_for('/'))
    canRole = processRole(120)

    if canRole == False:
        message = "You Don't Have Permission to Access Role"
        msgType="Error"
        return redirect(url_for('Information'))
    
    
    print("ProcessRole")
    
    operation = request.form['operation']
    if operation != "Delete" :
        roleName = request.form['roleName']
        canRole = 0
        canUser = 0
        CL111 = 0
        CL222 = 0
        CL333 = 0
        
        
        
        if request.form.get("canRole") != None :
            canRole = 1
        if request.form.get("canUser") != None :
            canUser = 1
        if request.form.get("CL111") != None :
            CL111 = 1
        if request.form.get("CL222") != None :
            CL222 = 1
        if request.form.get("CL333") != None :
            CL333 = 1
        
        
    
    print(1)
    unqid = request.form['unqid'].strip()
    print(operation)
    conn3 = pypyodbc.connect(connString, autocommit=True)
    cur3 = conn3.cursor()
    
    
    sqlcmd = ""
    if operation == "Create" :
        sqlcmd = "INSERT INTO Role (roleName, canRole, canUser, CL111, CL222, CL333) VALUES ('"+roleName+"', '"+str(canRole)+"', '"+str(canUser)+"', '"+str(CL111)+"', '"+str(CL222)+"', '"+str(CL333)+"')"
    if operation == "Edit" :
        print("edit inside")
        sqlcmd = "UPDATE Role SET roleName = '"+roleName+"', canRole = '"+str(canRole)+"', canUser = '"+str(canUser)+"', CL111 = '"+str(CL111)+"', CL222 = '"+str(CL222)+"', CL333 = '"+str(CL333)+"' WHERE RoleID = '"+unqid+"'" 
    if operation == "Delete" :
        conn4 = pypyodbc.connect(connString, autocommit=True)
        cur4 = conn4.cursor()
        sqlcmd4 = "SELECT roleID FROM UserTable WHERE roleID = '"+unqid+"'" 
        cur4.execute(sqlcmd4)
        dbrow4 = cur4.fetchone()
        if dbrow4:
            message = "You can't Delete this Role Since it Available in Users Table"
            msgType="Error"
            return redirect(url_for('Information')) 
        
        sqlcmd = "DELETE FROM Role WHERE RoleID = '"+unqid+"'" 
    print(operation, sqlcmd)
    if sqlcmd == "" :
        return redirect(url_for('Information')) 
    cur3.execute(sqlcmd)
    cur3.commit()
    
    return redirect(url_for('RoleListing')) 
    
'''
    Role Operation End
'''

import random
class RankSelection:
    def __init__(self):
        self.rankedList = list()

    def setup(self, population, SP):
        self.rankedList = sorted(population, key=lambda x: x.fitness, reverse=True)
        for x in range(0, len(self.rankedList)):
            self.rankedList[x].fitness

        N = len(self.rankedList)
        self.sum = len(population)
        sums = 0
        for x in range(0, len(population)):
            pos = N - x
            self.rankedList[x].fitness = 2 - SP + 2 * (SP - 1) * (pos - 1) / (N - 1)
            sums = sums + self.rankedList[x].fitness
            print(self.rankedList[x].fitness)
        print(sums)


    def select_individual(self, population):
        R = 0
        N = len(self.rankedList) - 1
        R = R + random.uniform(0, N)
        weight = 0
        while weight < len(population):
            random_index = random.randint(0, N)
            weight = weight + self.rankedList[random_index].fitness
        return self.rankedList[random_index]

    def select_mate(self, population, partner):
        R = 0
        N = len(self.rankedList) - 1
        R = R + random.uniform(0, N)
        weight = 0
        while weight < len(population):
            random_index = random.randint(0, N)
            weight = weight + self.rankedList[random_index].fitness
            if (weight >= len(population) and self.rankedList[random_index] == partner):
                weight = 0
        return self.rankedList[random_index]

    def get_parents(self, population):
        parent_one = self.select_individual(population)
        parent_two = self.select_mate(population, parent_one)
        return parent_one, parent_two


start = timeit.default_timer()

train_num = 40000
test_num = 40000

init_channel = 8

l2_loss_list = []

def read_filename():
  path = 'static/'

  cover_folder = 'static/input'
  stego_folder = 'static/output'

  cover_audio_list = []

  for i in xrange(10000):
    for j in xrange(4):
      filepath = path.format(folder = cover_folder, n1 = i + 1, n2 = j + 1)
      cover_audio_list.append(filepath)

  random.shuffle(cover_audio_list)

  print('Shuffle filename complete')

  audio_name_list = []

  for i in range(len(cover_audio_list)):
    cover_name = cover_audio_list[i]
    stego_name = cover_name.replace(cover_folder, stego_folder)
    audio_name_list.append(cover_name)
    audio_name_list.append(stego_name)



  train_audios_name = audio_name_list[: train_num]
  test_audios_name = audio_name_list[train_num : train_num + test_num]

  return train_audios_name, test_audios_name



def read_data():
  train_audios_name, test_audios_name = read_filename()

  train_audios_data = []
  for i in xrange(len(train_audios_name)):
    audio_data = wavfile.read(train_audios_name[i])[1]

    train_audios_data.append(audio_data)

  test_audios_data = []
  for i in xrange(len(test_audios_name)):
    audio_data = wavfile.read(test_audios_name[i])[1]

    test_audios_data.append(audio_data)

  train_labels_data = [0, 1] * (train_num / 2)
  test_labels_data = [0, 1] * (test_num / 2)

  train_audios_data = np.asarray(train_audios_data)
  train_labels_data = np.asarray(train_labels_data)
  test_audios_data = np.asarray(test_audios_data)
  test_labels_data = np.asarray(test_labels_data)


  return train_audios_data, test_audios_data, train_labels_data, test_labels_data

def weight_variable(shape,):
  initial = tf.truncated_normal(shape, stddev=0.1)
  weight = tf.Variable(initial, name='weight')

  l2_loss_list.append(tf.nn.l2_loss(weight))

  return weight

def bias_variable(shape):
  initial = tf.constant(0.0, shape = shape)
  return tf.Variable(initial, name='bias')

def compute_time():
  stop = timeit.default_timer()
  seconds = stop - start
  m, s = divmod(seconds, 60)
  h, m = divmod(m, 60)
  d, h = divmod(h, 24)
  print('Run time: %d:%02d:%02d:%02d' % (d, h, m, s))

def conv_act(input, w_shape, b_shape, name):
  with tf.variable_scope(name):
    w_conv = weight_variable(w_shape)
    b_conv = bias_variable(b_shape)

    z_conv = tf.nn.conv2d(input, w_conv, strides=[1, 1, 1, 1], padding='SAME') + b_conv
    h_conv = tf.nn.tanh(z_conv)

    return h_conv

def conv_without_act(input, w_shape, b_shape, name):
  with tf.variable_scope(name):
    w_conv = weight_variable(w_shape)
    b_conv = bias_variable(b_shape)

    z_conv = tf.nn.conv2d(input, w_conv, strides=[1, 1, 1, 1], padding='SAME') + b_conv

    return z_conv


def conv_subsample_without_act(input, channel, name):
  with tf.variable_scope(name):
    w_conv = weight_variable([1, 3, channel, channel])
    b_conv = bias_variable([channel])

    z_conv = tf.nn.conv2d(input, w_conv, strides=[1, 1, 2, 1], padding='SAME') + b_conv

    return z_conv


def inference(audios):
  audios_reshape = tf.reshape(audios, [-1, 1, 16000, 1])

  filter_kernel = np.array([-1, 2, -1])
  filter_kernel = filter_kernel.reshape((1, filter_kernel.shape[0], 1, 1))

  audios_preprocess = tf.nn.conv2d(audios_reshape, filter_kernel, strides=[1, 1, 1, 1], padding='VALID')

  with tf.variable_scope('group1'):
    output = conv_without_act(audios_preprocess, [1, 5, 1, 1], [1], name='conv1')
    output = conv_without_act(output, [1, 1, 1, init_channel], [init_channel], name='conv2')
    output = conv_subsample_without_act(output, init_channel, name='subsample')


  with tf.variable_scope('group2'):
    output = conv_without_act(output, [1, 5, init_channel, init_channel], [init_channel], name='conv1')
    output = conv_without_act(output, [1, 1, init_channel, init_channel * 2], [init_channel * 2], name='conv2')
    output = conv_subsample_without_act(output, init_channel * 2, name='subsample')


  with tf.variable_scope('group3'):
    output = conv_act(output, [1, 5, init_channel * 2, init_channel * 2], [init_channel * 2], name='conv1')
    output = conv_act(output, [1, 1, init_channel * 2, init_channel * 4], [init_channel * 4], name='conv2')
    output = tf.nn.max_pool(output, ksize=[1, 1, 3, 1], strides=[1, 1, 2, 1], padding='SAME', name='max_pool')


  with tf.variable_scope('group4'):
    output = conv_act(output, [1, 5, init_channel * 4, init_channel * 4], [init_channel * 4], name='conv1')
    output = conv_act(output, [1, 1, init_channel * 4, init_channel * 8], [init_channel * 8], name='conv2')
    output = tf.nn.max_pool(output, ksize=[1, 1, 3, 1], strides=[1, 1, 2, 1], padding='SAME', name='max_pool')


  with tf.variable_scope('group5'):
    output = conv_act(output, [1, 5, init_channel * 8, init_channel * 8], [init_channel * 8], name='conv1')
    output = conv_act(output, [1, 1, init_channel * 8, init_channel * 16], [init_channel * 16], name='conv2')
    output = tf.nn.max_pool(output, ksize=[1, 1, 3, 1], strides=[1, 1, 2, 1], padding='SAME', name='max_pool')

  with tf.variable_scope('group6'):
    output = conv_act(output, [1, 5, init_channel * 16, init_channel * 16], [init_channel * 16], name='conv1')
    output = conv_act(output, [1, 1, init_channel * 16, init_channel * 32], [init_channel * 32], name='conv2')
    output = tf.nn.max_pool(output, ksize=[1, 1, 3, 1], strides=[1, 1, 2, 1], padding='SAME', name='max_pool')


  with tf.variable_scope('group7'):
    output = conv_act(output, [1, 5, init_channel * 32, init_channel * 32], [init_channel * 32], name='conv1')
    output = conv_act(output, [1, 1, init_channel * 32, init_channel * 64], [init_channel * 64], name='conv2')
    output = tf.nn.avg_pool(output, ksize=[1, 1, 250, 1], strides=[1, 1, 250, 1], padding='SAME', name='global_avg_pool')


  with tf.variable_scope('readout'):
    output = tf.reshape(output, [-1, init_channel * 64])

    w_fc = weight_variable([init_channel * 64, 2])
    b_fc = bias_variable([2])

    logits = tf.matmul(output, w_fc) + b_fc

  return logits

def loss(logits, labels):
  cross_entropy = tf.nn.sparse_softmax_cross_entropy_with_logits(logits=logits, labels=labels, name='cross_entropy_per_example')

  cross_entropy_mean = tf.reduce_mean(cross_entropy, name='cross_entropy')

  weight_decay = 0.0
  l2_loss = tf.add_n(l2_loss_list, name='l2_loss')

  loss = cross_entropy_mean + l2_loss * weight_decay

  return loss

def train(loss):
  global_step = tf.Variable(0, name='global_step', trainable=False)
  starter_learning_rate = 0.0001
  learning_rate = tf.train.exponential_decay(starter_learning_rate, global_step, 10000, 1.0, staircase=True)

  train_op = tf.train.AdamOptimizer(0.0001).minimize(loss, global_step=global_step)

  return train_op, learning_rate, global_step

def evaluation(logits, labels):
  correct = tf.equal(tf.cast(tf.argmax(logits, 1), tf.int32), labels)

  true_labels = tf.equal(labels, 1)

  true_positive = tf.logical_and(true_labels, correct)
  true_negative = tf.logical_and(tf.logical_not(true_labels), correct)
  false_positive = tf.logical_and(tf.logical_not(true_labels), tf.logical_not(correct))
  false_negative = tf.logical_and(true_labels, tf.logical_not(correct))

  correct_count = tf.reduce_sum(tf.cast(correct, tf.int32))

  tp_count = tf.reduce_sum(tf.cast(true_positive, tf.int32))
  tn_count = tf.reduce_sum(tf.cast(true_negative, tf.int32))
  fp_count = tf.reduce_sum(tf.cast(false_positive, tf.int32))
  fn_count = tf.reduce_sum(tf.cast(false_negative, tf.int32))

  return correct_count, tp_count, tn_count, fp_count, fn_count

def get_acc(correct_count, audios_placeholder, labels_placeholder, audios_data, labels_data):
  batch_size = 50

  true_count = 0

  steps_per_epoch = len(audios_data) // batch_size
  num_examples = steps_per_epoch * batch_size

  for step in xrange(steps_per_epoch):
    feed_dict={audios_placeholder: audios_data[step * batch_size: step * batch_size + batch_size],
      labels_placeholder: labels_data[step * batch_size: step * batch_size + batch_size]}
    true_count += correct_count.eval(feed_dict=feed_dict)

  accuracy = float(true_count) / num_examples


  return accuracy


def save_graph(sess):
  save_graph = os.path.basename(__file__).replace('.py', '_graph')
  train_writer = tf.train.SummaryWriter('./{}'.format(save_graph), sess.graph)
  train_writer.close()

def save_ckpt(saver, sess):
    save_file = '{}.ckpt'.format(os.path.basename(__file__).replace('.py', ''))
    saver.save(sess,  './{}'.format(save_file), write_meta_graph=False)

def shuffle(data, labels):
  data_len = len(data)

  temp0 = np.arange(data_len / 2)
  np.random.shuffle(temp0)

  temp1 = np.reshape(temp0, (data_len / 2, 1))
  temp1 = temp1 * 2
  temp2 = temp1 + 1
  temp3 = np.concatenate((temp1, temp2), axis=1)
  perm = np.reshape(temp3, data_len)

  data = data[perm]
  labels = labels[perm]

def divide_train_set(train_audios, train_labels):
  proportion = 0.8

  shuffle(train_audios, train_labels)

  new_train_audios = train_audios[: int(len(train_audios) * 0.8)]
  new_train_labels = train_labels[: int(len(train_audios) * 0.8)]

  valid_audios = train_audios[int(len(train_audios) * 0.8) :]
  valid_labels = train_labels[int(len(train_audios) * 0.8) :]

  return new_train_audios, new_train_labels, valid_audios, valid_labels

def main():
  audios_placeholder = tf.placeholder(tf.float32, [None, 16000])
  labels_placeholder = tf.placeholder(tf.int32, [None])

  logits = inference(audios_placeholder)

  loss_op = loss(logits, labels_placeholder)

  train_op, lr_op, step_op = train(loss_op)

  correct_count, tp_count, tn_count, fp_count, fn_count = evaluation(logits, labels_placeholder)

  sess = tf.InteractiveSession()

  saver = tf.train.Saver()


  # save_graph(sess)
  batch_size = 64

  # for i in range(100):
  valid_acc_list = []
  train_acc_list = []

  batch_index = 0

  train_audios_data, test_audios, train_labels_data, test_labels = read_data()
  train_audios, train_labels, valid_audios, valid_labels = divide_train_set(train_audios_data, train_labels_data)

  if 'load' in sys.argv:
    load_file = '{}.ckpt'.format(os.path.basename(__file__).replace('.py', ''))
    saver.restore(sess, './{}'.format(load_file))
  else:
    sess.run(tf.initialize_all_variables())

  for j in range(10000000):
    start = batch_index
    batch_index += batch_size

    if batch_index > len(train_audios):
      start = 0
      batch_index = batch_size

      shuffle(train_audios, train_labels)

    end = batch_index

    audios_batch = train_audios[start : end]
    labels_batch = train_labels[start : end]

    _, loss_value, lr, step = sess.run([train_op, loss_op, lr_op, step_op],
      feed_dict={audios_placeholder: audios_batch, labels_placeholder: labels_batch})

    if step % 100 == 0:
      filename = os.path.basename(__file__)


    if step % 1000 == 0:

      valid_accuracy = get_acc(correct_count, audios_placeholder, labels_placeholder, valid_audios, valid_labels)
      valid_acc_list.append(valid_accuracy)

      train_accuracy = get_acc(correct_count, audios_placeholder, labels_placeholder, train_audios, train_labels)
      train_acc_list.append(train_accuracy)

      save_ckpt(saver, sess)
      compute_time()


    if step % 50000 ==0:
      break


@app.route("/FilesUpload")
def FilesUpload():
        return render_template('FilesUpload.html')


@app.route("/ProcessFilesUploadOperation", methods=['POST'])
def ProcessFilesUploadOpertion():

    pyfiles = request.files.getlist('pyfile1')
    for file in pyfiles:
        f = os.path.join('static/input', file.filename)
        file.save(f)


    return render_template('FilesUploadResult.html', processResult="Success!!!. Python Files Uploaded. ")


@app.route("/EncodeFileListing")
def EncodeFileListing():
    global message, msgType

    searchData = request.args.get('searchData')
    print(searchData)
    if searchData == None:
        searchData = "";

    from os import listdir
    from os.path import isfile, join
    pyfiles = [f for f in listdir('static/input') if isfile(join("static/input", f))]
    print(pyfiles)
    records = []
    for file in pyfiles:
        print(file)
        if searchData == "":
            records.append(file)
        else:
            if file.__contains__(searchData):
                records.append(file)

    return render_template('EncodeFileListing.html', records=records, searchData=searchData)


@app.route("/InputText")
def InputText():

    wavefilename = request.args.get('wavefilename')
    print(wavefilename,"wavefilenamewavefilenamewavefilenamewavefilename")
    return render_template('InputText.html', wavefilename=wavefilename)
import wave

@app.route("/ProcessEncodeWatermark", methods=['POST'])
def ProcessEncodeWatermark():

    wavefilename = request.form['wavefilename']
    secrettxt = request.form['secrettxt']

    song = wave.open("static/input/"+wavefilename, mode='rb')
    frame_bytes = bytearray(list(song.readframes(song.getnframes())))
    RankSelection()
    secrettxt = secrettxt + int((len(frame_bytes) - (len(secrettxt) * 8 * 8)) / 8) * '#'

    bits = list(map(int, ''.join([bin(ord(i)).lstrip('0b').rjust(8, '0') for i in secrettxt])))

    for i, bit in enumerate(bits):
        frame_bytes[i] = (frame_bytes[i] & 254) | bit
    frame_modified = bytes(frame_bytes)


    with wave.open("static/output/output-"+wavefilename, 'wb') as fd:
        fd.setparams(song.getparams())
        fd.writeframes(frame_modified)
    song.close()
    return render_template('EncodeWatermarkResult.html')




@app.route("/DecodeFileListing")
def DecodeFileListing():
    global message, msgType

    searchData = request.args.get('searchData')
    print(searchData)
    if searchData == None:
        searchData = "";

    from os import listdir
    from os.path import isfile, join
    pyfiles = [f for f in listdir('static/output') if isfile(join("static/output", f))]
    print(pyfiles)
    records = []
    for file in pyfiles:
        print(file)
        if searchData == "":
            records.append(file)
        else:
            if file.__contains__(searchData):
                records.append(file)

    return render_template('DecodeFileListing.html', records=records, searchData=searchData)



@app.route("/ProcessDecodeWatermark")
def ProcessDecodeWatermark():

    wavefilename = request.args.get('wavefilename')
    print(wavefilename)
    song = wave.open("static/output/"+wavefilename, mode='rb')
    frame_bytes = bytearray(list(song.readframes(song.getnframes())))
    extracted = [frame_bytes[i] & 1 for i in range(len(frame_bytes))]
    string = "".join(chr(int("".join(map(str, extracted[i:i + 8])), 2)) for i in range(0, len(extracted), 8))
    watermarktext = string.split("###")[0]
    song.close()

    return render_template('DecodeWatermarkResult.html', watermarktext=watermarktext)



if __name__ == "__main__":
    app.run()

