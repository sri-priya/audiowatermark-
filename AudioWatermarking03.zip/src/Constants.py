serverName = "WISEN\SQLEXPRESS"
databaseName = "AudioWatermarking03"
connString = 'Driver={SQL Server};Server='+serverName+';Integrated_Security=true;Database='+databaseName